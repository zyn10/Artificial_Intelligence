#18F-0326 Abdul Salam Wasti

from q1 import *
from q2 import *

q1sol()
q2sol()


# Press the green button in the gutter to run the script.
#if __name__ == '__main__':


# See PyCharm help at https://www.jetbrains.com/help/pycharm/
